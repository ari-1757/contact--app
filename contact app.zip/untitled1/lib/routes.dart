
import 'package:flutter/material.dart';
import 'screens/auth_screen.dart';
import 'screens/home_screen.dart';
import 'screens/contact_list_screen.dart';
import 'screens/add_contact_screen.dart';

class Routes {
  static Route<dynamic> generateRoute(RouteSettings settings) {
    switch (settings.name) {
      case '/':
        return MaterialPageRoute(builder: (_) => AuthScreen());
      case '/home':
        return MaterialPageRoute(builder: (_) => HomeScreen());
      case '/contacts':
        return MaterialPageRoute(builder: (_) => ContactListScreen());
      case '/add-contact':
        return MaterialPageRoute(builder: (_) => AddContactScreen());
      default:
        return MaterialPageRoute(
          builder: (_) => Scaffold(
            body: Center(child: Text('No route defined for ${settings.name}')),
          ),
        );
    }
  }
}
